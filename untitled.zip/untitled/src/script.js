const express = require("express");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const app = express();
const PORT = 3000;

app.use(express.json());

mongoose.connect("mongodb://localhost:27017/messaging-app", { useNewUrlParser: true, useUnifiedTopology: true });

// User schema
const userSchema = new mongoose.Schema({
    phone: { type: String, unique: true },
    password: String
});

const User = mongoose.model("User", userSchema);

// Register endpoint
app.post("/register", async (req, res) => {
    const { phone, password } = req.body;
    try {
        const user = new User({ phone, password });
        await user.save();
        res.status(201).send("User registered");
    } catch (error) {
        res.status(400).send("User already exists");
    }
});

// Login endpoint
app.post("/login", async (req, res) => {
    const { phone, password } = req.body;
    const user = await User.findOne({ phone, password });
    if (user) {
        const token = jwt.sign({ phone }, "SECRET_KEY");
        res.json({ token });
    } else {
        res.status(400).send("Invalid credentials");
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
}); 

const apiUrl = "http://localhost:3000";  // Your server URL

// Register
async function register() {
    const phone = document.getElementById("phone").value;
    const password = document.getElementById("password").value;
    const response = await fetch(`${apiUrl}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, password })
    });
    if (response.ok) {
        alert("Registered successfully");
    } else {
        alert("User already exists");
    }
}

// Login
async function login() {
    const phone = document.getElementById("phone").value;
    const password = document.getElementById("password").value;
    const response = await fetch(`${apiUrl}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, password })
    });
    if (response.ok) {
        const data = await response.json();
        localStorage.setItem("token", data.token);
        document.getElementById("auth-container").style.display = "none";
        document.getElementById("message-container").style.display = "block";
    } else {
        alert("Invalid credentials");
    }
}

// Send Message
function sendMessage() {
    const message = document.getElementById("message").value;
    if (message) {
        const messages = document.getElementById("messages");
        const messageElem = document.createElement("div");
        messageElem.textContent = message;
        messages.appendChild(messageElem);
        document.getElementById("message").value = "";
    }
}